package Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class TestLine {
	private int count;
	
	private void countLine(File sourceFile) throws IOException{
		BufferedReader br=null;
		try{
			//�½��ļ�������
			br=new BufferedReader(new FileReader(sourceFile));
			while(br.readLine()!=null){
				count++;
			}
		}finally{
			br.close();
		}
	}
	private void countDir(String sourceDir) throws IOException{
		File fSourceDir=new File(sourceDir);
		if(!fSourceDir.exists()||!fSourceDir.isDirectory()){
			System.out.println("ԴĿ¼�����ڣ�����");
			return;
		}
		//����Ŀ¼�µ��ļ���Ŀ¼
		File[] file=fSourceDir.listFiles();
		for(int i=0;i<file.length;i++){
			if(file[i].isFile()){
				if(file[i].getName().toLowerCase().endsWith(".java")){
					countLine(file[i]);
				}
			}
			if(file[i].isDirectory()){
				String subSourceDir=sourceDir+File.separator+file[i].getName();
				countDir(subSourceDir);
			}
		}
	}
	public static void main(String[] args) throws IOException {
		TestLine tcd=new TestLine();
		tcd.countDir("E:\\Java\\���ģʽ\\SHOW_TIME10");
		System.out.println("�������������"+tcd.count);
	}
}
