package Test;

public class TestInteger {
	public static void main(String [] args) {
		String s = "123";
		int s1 = Integer.parseInt(s);
		System.out.println(s1);
	}
}
