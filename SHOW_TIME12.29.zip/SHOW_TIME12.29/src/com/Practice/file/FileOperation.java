package com.Practice.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class FileOperation {
	public void write(String fileName,String message) throws Exception {
		FileWriter write = new FileWriter(fileName);
		BufferedWriter fw = new BufferedWriter(write);
		fw.write(message);
		fw.close();
	}
	
	public String read(String fileName) throws Exception{
		FileReader reader = new FileReader(fileName);
		BufferedReader br = new BufferedReader(reader);
		String message= br.readLine();
		br.close();
		return message;
	}
}
