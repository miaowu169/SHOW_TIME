package com.Practice.Listener;

import com.Practice.Exception.IPConfigException;

import com.Practice.Module.workModule;
import com.Practice.time.TestNTP;

public class Listener {	
	public void Update(String iPget) throws IPConfigException {
		TestNTP TP = new TestNTP();
		TP.setTimeServerUrl(iPget);

		new workModule().showworkModule();
	}	
}
