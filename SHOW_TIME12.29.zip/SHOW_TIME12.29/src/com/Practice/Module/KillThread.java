package com.Practice.Module;

public class KillThread {
	public boolean killThreadByName(String name) {		 
		ThreadGroup currentGroup = Thread.currentThread().getThreadGroup();
		int noThreads = currentGroup.activeCount();
		Thread[] lstThreads = new Thread[noThreads];
		currentGroup.enumerate(lstThreads);
 
		for (int i = 0; i < noThreads; i++) {
			String nm = lstThreads[i].getName();
			if (nm.equals(name)) { 
				lstThreads[i].interrupt(); 
				return true; 
			} 
		}
		 return false; 
	}
}
