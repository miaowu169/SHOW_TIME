package com.Practice.Module;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import com.Practice.Clock.Clock;
import com.Practice.Clock.GPS;
import com.Practice.Clock.UTC;
import com.Practice.Clock.����;
import com.Practice.Clock.����;
//import com.Practice.time.AudioPlay;

public class workModule extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	static String title,titleFontType,titleFontColor;
	Color titlefontColor;
	static int titleMode,titleFontSize;
	static boolean lock = false;
	static int count = 0;
	int millis = 8*1000;
	
	Font f4;
	
	public static boolean flag = true;
	static JLabel titleLabel = new JLabel();
	static JPanel titlePanel;
	static JPanel ClockPanel;
	static JFrame f;
	JMenuBar menuBar = new JMenuBar();
	
	class NewPanel extends JPanel
	{
		/**
		 * 
		 */
		int mode = 0;
		private static final long serialVersionUID = 1L;

		public NewPanel(int mode)
		{
			this.mode = mode;
		}
 
		public void paintComponent(Graphics g)
		{
			int x=0,y=0;
			java.net.URL imgURL = null;
			if(mode == 0) {
				imgURL=getClass().getResource("beijing2.jpg");
			}else if(mode == 1) {
				imgURL=getClass().getResource("����1.jpg");
			}
			//test.jpg�ǲ���ͼƬ����Demo.java����ͬһĿ¼��
			ImageIcon icon=new ImageIcon(imgURL);
			g.drawImage(icon.getImage(),x,y,getSize().width,getSize().height,this);
			while(true)
			{
				g.drawImage(icon.getImage(),x,y,this);
				if(x>getSize().width && y>getSize().height)break;
				//��δ�����Ϊ�˱�֤�ڴ��ڴ���ͼƬʱ��ͼƬ���ܸ�����������
				if(x>getSize().width)
				{
					x=0;
					y+=icon.getIconHeight();
				}
				else
					x+=icon.getIconWidth();
			}
		}
	}
	
	public void showworkModule() {
		f = new JFrame("Clock");
		
		NewPanel ClockPanel = new NewPanel(0);
		NewPanel titlePanel = new NewPanel(1);
		
		title = "���ر�׼ʱ�� ��Դ��UTC��NIM��";
		titleFontType = "΢���ź�";
		titleFontSize = 60;
		titlefontColor = Color.WHITE;
		titleMode = 1;
			
		menuBar.setBounds(0, 0, 30, 450);
		this.setJMenuBar(menuBar);
		
		JMenuItem item0 = new JMenuItem("");
		menuBar.add(item0);
		item0.setBounds(0, 0, 40, 20);
		
		JMenu menu = new JMenu("�鿴");
		menuBar.add(menu);
		JMenuItem item6 = new JMenuItem("������Ϣ");
		JMenuItem item9 = new JMenuItem("�汾");
		menu.add(item6);
		menu.add(item9);
		item6.addActionListener(this);
		item9.addActionListener(this);		
		
		JMenu menu1 = new JMenu("����");
		menuBar.add(menu1);
		JMenu menu2 = new JMenu("������ɫ����");
		menu1.add(menu2);
		JMenuItem item1 = new JMenuItem("��ɫ");
		item1.addActionListener(this);
		JMenuItem item2 = new JMenuItem("��ɫ");
		item2.addActionListener(this);
		JMenuItem item3 = new JMenuItem("��ɫ");
		item3.addActionListener(this);
		JMenuItem item12 = new JMenuItem("��ɫ");
		item12.addActionListener(this);
		menu2.add(item1);
		menu2.add(item2);
		menu2.add(item3);
		menu2.add(item12);

		JMenuItem item10 = new JMenuItem("IP��ַ����");
		menu1.add(item10);
		item10.addActionListener(this);
			
		JMenu menu3 = new JMenu("����");
		menuBar.add(menu3);
		JMenuItem item7 = new JMenuItem("ˢ��");
		item7.addActionListener(this);		
		JMenuItem item8 = new JMenuItem("�˳�");	
		item8.addActionListener(this);
		menu3.add(item7);
		menu3.addSeparator();
		menu3.add(item8);
		
		f.setLayout(new BorderLayout());
		ClockPanel.setLayout(new GridLayout(1,4,0,0));
		Clock c = new GPS();
		Clock c2 = new ����();
		Clock c3 = new ����();
		Clock c4 = new UTC();
		
		new Thread(new Runnable(){
			 public void run() {
				c.Init();
				Thread.currentThread().setName("GPS");
				c.showUI();
			}
		}).start();
		
		new Thread(new Runnable(){
			public void run() {
				// TODO Auto-generated method stub
				c2.Init();
				Thread.currentThread().setName("beidou");
				c2.showUI();
			}
		}).start();
	
		new Thread(new Runnable(){
			public void run() {
				c3.Init();
				Thread.currentThread().setName("beijing");
				c3.showUI();
			}
		}).start();
	
		new Thread(new Runnable() {
			public void run() {
				c4.Init();
				Thread.currentThread().setName("UTC");
				c4.showUI();
			}
		}).start();
		
//		ThreadGroup currentGroup =
//				 
//				Thread.currentThread().getThreadGroup();
//
//		int noThreads = currentGroup.activeCount();
//
//		Thread[] lstThreads = new Thread[noThreads];
//
//		currentGroup.enumerate(lstThreads);
//
//		for (int i = 0; i < noThreads; i++)
//			System.out.println("�̺߳ţ�" + i + " = " + lstThreads[i].getName());
		


		
//		if(flag == true) {
//			new AudioPlay("src//7987.wav").start();
//			flag = false;
//		}
		
		f.setJMenuBar(menuBar);
			
		//Image img=Toolkit.getDefaultToolkit().getImage("title.gif");//����ͼ��
		//f.setIconImage(img);
		
		f.setSize(1940,1090);	//////
		
		//f.setResizable(false);
		
	    f4 = new Font("΢���ź�",Font.BOLD,80);///////////////
		titleLabel.setForeground(titlefontColor);
		titleLabel.setFont(f4);
		titleLabel.setText(title);
		titlePanel.setLayout(null);						//���ñ����λ��
		titleLabel.setBounds(370, 50, 1500, 150);
		titlePanel.setPreferredSize(new Dimension(1200,200));////////////
		titlePanel.add(titleLabel);

		f.add(titlePanel,BorderLayout.NORTH);

		ClockPanel.add(c);
		ClockPanel.add(c2);
		ClockPanel.add(c3);
		ClockPanel.add(c4);
		f.add(ClockPanel,BorderLayout.CENTER);
		
	
		titlePanel.setBackground(new java.awt.Color(0,0,139));
		ClockPanel.setBackground(new java.awt.Color(0,0,139));

		
		 Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		 f.setLocation((dim.width - f.getWidth()) / 2, (dim.height - f.getHeight()) / 2);//���ô��ھ���
		
		//f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
		
	public void closeEmptyWindow() {
		f.dispose();
	}

	public void actionPerformed(ActionEvent e) {
			new ModuleJudge().actionPerformed(e);	
	}
}