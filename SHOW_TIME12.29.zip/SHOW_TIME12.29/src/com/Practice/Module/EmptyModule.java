package com.Practice.Module;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;

import com.Practice.Clock.EmptyClock;
import com.Practice.Clock.EmptyClock2;

public class EmptyModule {
	static JFrame f = new JFrame("Clock");
	Container panel=f.getContentPane();
	public void showEmptyModule() {
		EmptyClock2 c = new EmptyClock2();
		c.showUI();

		panel.setBackground(Color.BLUE);
		f.setLayout(new GridLayout(1,4,0,0));
	
		EmptyClock c2 = new EmptyClock();
		c2.showUI();
	
		EmptyClock c3 = new EmptyClock();
		c3.showUI();
	
		EmptyClock c4 = new EmptyClock();
		c4.showUI();
		
		Image img=Toolkit.getDefaultToolkit().getImage("title.gif");//����ͼ��
		f.setIconImage(img);
		f.setSize(1500,450);
		f.setResizable(false);
		f.add(c);
		f.add(c2);
		f.add(c3);
		f.add(c4);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);		
	}
	
	public void closeEmptyWindow() {
		f.dispose();
	}
}
