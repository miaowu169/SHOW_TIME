package com.Practice.Module;

import java.awt.Color;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import com.Practice.MenuEvent.ConfigView;
import com.Practice.file.FileOperation;
import com.Practice.time.IPConfig;
import com.Practice.time.TimeConfig;

public class ModuleJudge extends workModule{

	private static final long serialVersionUID = 1L;

	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();// ��ȡActionCommand ,�����ж�����һ����ť�������
		if (cmd.equals("�˳�")) {
			System.exit(0);
		} else if (cmd.equals("ˢ��")) {
			new workModule().closeEmptyWindow();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			new workModule().showworkModule();
		} else if (cmd.equals("��ɫ")) {
			ClockPanel.setBackground(Color.BLACK);
			titlePanel.setBackground(Color.BLACK);
			try {
				new FileOperation().write("ColorConfig.txt","��ɫ");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (cmd.equals("��ɫ")) {
			ClockPanel.setBackground(Color.GRAY);
			titlePanel.setBackground(Color.GRAY);
			try {
				new FileOperation().write("ColorConfig.txt","��ɫ");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (cmd.equals("��ɫ")) {
			ClockPanel.setBackground(Color.PINK);
			titlePanel.setBackground(Color.PINK);
			try {
				new FileOperation().write("ColorConfig.txt","��ɫ");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else if(cmd.equals("��ɫ")) {
			ClockPanel.setBackground(Color.BLUE);
			titlePanel.setBackground(Color.BLUE);
			try {
				new FileOperation().write("ColorConfig.txt","��ɫ");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else if(cmd.equals("������Ϣ")) {
			new ConfigView().showConfig();
		}else if(cmd.equals("�汾")) {
			JOptionPane.showMessageDialog(this, "�汾Ver1.0", "About", JOptionPane.INFORMATION_MESSAGE);
		}else if(cmd.equals("IP��ַ����")) {
			new IPConfig().ConfigUI();
		}else if(cmd.equals("ʱ���ȡ����")) {
			new TimeConfig().ConfigUI();
		}else if(cmd.equals("�鿴")) {
			new ConfigView().showConfig();
		}
	}
}
