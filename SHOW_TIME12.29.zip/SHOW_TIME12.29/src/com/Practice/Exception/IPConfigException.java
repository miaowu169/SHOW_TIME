package com.Practice.Exception;

public class IPConfigException extends Exception{
	private static final long serialVersionUID = 1L;

	public IPConfigException() {
		super();
	}
	
	public IPConfigException(String message) {
		super(message);
	}
}
