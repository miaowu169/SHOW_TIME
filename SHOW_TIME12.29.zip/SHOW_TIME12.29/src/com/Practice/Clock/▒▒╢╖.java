package com.Practice.Clock;

import java.awt.Color;

import javax.swing.JLabel;


public class ���� extends Clock{    
	private static final long serialVersionUID = 1L;
	static JLabel l = new JLabel("����ʱ��");
  
	public ����(){        
        add(l);
       
        l.setForeground(Color.white);
        l.setBounds(155, 100 , 200, 50);
        l.setFont(f);
       
        add(display2);
        display2.setForeground(Color.WHITE);
        display2.setBounds(125, 240, 250, 50);
        display2.setFont(f3);
        setVisible(true);
    }

	public void showUI(){
        new Thread() {
            public void run() {
            	//System.out.println(Thread.currentThread().getName());
               	setTimer(1);
                while (flag) 
                {
                	secs[1]++;
                	if(secs[1] == 60) {
                		secs[1] = 0;
                		mins[1]++;
                	}
                	if(mins[1] == 60) {
                		hours[1] += 1;
                		mins[1] = 0;
                	}
                	if(hours[1] == 24) {
                		hours[1] = 0;
                	}
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                    setTime(hours[1],mins[1],secs[1]);
                    
                    repaint();
                    //System.out.println("������"+secs[1]);
                    showTime();
                }
            }
        }.start();
        
    }
}
