package com.Practice.Clock;

import java.awt.*;

import javax.swing.*;

public class ���� extends Clock{    

	private static final long serialVersionUID = 1L;
	static JLabel l = new JLabel("����ʱ��");
	
	public ����(){ 
		add(l);
        
        l.setForeground(Color.white);
        l.setBounds(155, 100 , 200, 50);
        l.setFont(f);
      
        add(display2);
        display2.setForeground(Color.WHITE);
        display2.setBounds(125, 240, 250, 50);
        display2.setFont(f3);
        setVisible(true);
    }

	public void showUI(){
        new Thread() {
            public void run() {  
            	//System.out.println(Thread.currentThread().getName());
            	setTimer(1);
                while (flag) 
                {
                	sec++;
                	if(sec == 60) {
                		sec = 0;
                		min++;
                	}
                	if(min == 60) {
                		hour += 1; 
                		min = 0;
                	}
                	if(hour == 24) {
                		hour = 0;
                	}
        
                	try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                    setTime(hour,min,sec);
                    repaint();
                    showTime();
                    //System.out.println("������"+ sec);
                }
            }
        }.start();
    }
}
