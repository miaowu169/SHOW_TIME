package com.Practice.Clock;

/*
 * �����ð�ť�ı���
 */

import java.awt.BasicStroke;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JComponent;
import javax.swing.JLabel;

public class EmptyClock extends JComponent{
    protected Font f = new Font("΢���ź�",Font.PLAIN,22);
    protected Font f3 = new Font("΢���ź�",Font.BOLD,26);
    protected Font f2 = new Font("΢���ź�",Font.BOLD,10);
   // private JLabel l = new JLabel("����ʱ��");
   // private JLabel l1 = new JLabel("����ʱ�� ��");
    protected JLabel display = new JLabel();
    protected JLabel display2 = new JLabel("");
    
    protected Graphics2D g;
    final double PI = Math.PI;
	
	public EmptyClock(){        
        add(display);
        display.setBounds(195, 50, 150, 20);
        display.setForeground(Color.WHITE);
        display.setFont(f);
//        //display.setBorder(BorderFactory.createLineBorder(Color.black));
        add(display2);
        display2.setForeground(Color.WHITE);
        display2.setBounds(135, 110, 250, 50);
        display2.setFont(f3);
        setVisible(true);
    }
	
	private static final long serialVersionUID = 1L;

	
	public void paintComponent(Graphics g1){
        double x,y;
        super.paintComponent(g1);
        g = (Graphics2D) g1;
        //����ݿ��ؿ�
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        //������
        g.setPaint(new GradientPaint(5,40,Color.WHITE,15,50,Color.WHITE,true));
        g.setStroke( new BasicStroke(3,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL));
        g.drawOval(123, 178, 150, 150);
        g.fillOval(195, 250, 8, 8);
        g.setColor(Color.WHITE);
        
        //��60����
        for(int i = 0;i < 60;i++)
        {
            double[] co = new double[2];
            co = paint_Dot(i * 2 * PI / 60);
            x = co[0];
            y = co[1];
            if(i == 0 || i == 15 || i == 30 || i == 45)//��3,6,9,12�ĸ����
            {
                g.fillOval((int)(x - 5 + 200),(int)(y - 5 + 255),6,6);
            }
            else//����С��
            {
                g.fillOval((int)(x - 2.5 + 200),(int)(y - 2.5 + 255),2,2);
            }
        }
        
        
        
        //���ĸ�����
        g.setFont(f2);
        g.drawString("3", 253, 257);
        g.drawString("6", 195, 315);
        g.drawString("9", 136, 258);
        g.drawString("12", 192, 200);
    }
	
	public void showUI(){
        repaint();
    }
	
    
    public double[] paint_Dot(double angle){
        double[] co = new double[2];
        co[0] = 67 * Math.cos(angle);//������
        co[1] = 67 * Math.sin(angle);//������
        return co;
    }
}
