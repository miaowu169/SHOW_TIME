package com.Practice.Clock;

import java.awt.Color;
import javax.swing.JLabel;


public class UTC extends Clock{  
	private static final long serialVersionUID = 1L;
	static JLabel l = new JLabel("UTCʱ��");
	
	public UTC(){        
        add(l);

        l.setForeground(Color.white);
        l.setBounds(155, 100 , 200, 50);
        l.setFont(f);
        
        add(display2);
        display2.setForeground(Color.WHITE);
        display2.setBounds(125, 240, 250, 50);
        display2.setFont(f3);
        setVisible(true);
    }
	   
	public void showUI(){ 
        new Thread() {
            public void run() {
            	//System.out.println(Thread.currentThread().getName());
            	setTimer(1);
                while (flag) 
                {
                	//System.out.println("UTC:" + sec);
                	secs[2]++;
                	if(secs[2] == 60) {
                		secs[2] = 0;
                		mins[2]++;
                	}
                	if(mins[2] == 60) {
                		hours[2] += 1;
                		mins[2] = 0;
                	}
                	if(hours[2] == 24) {
                		hours[2] = 0;
                	}
					try {
						Thread.sleep(1000);
						//System.out.println(UTCHours);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
					setTime(hours[2],mins[2],secs[2]);
					repaint();
					
					showTime();
                }
            }
        }.start();
    }
}



