package com.Practice.Clock;

import java.awt.*;

import javax.swing.*;


public class GPS extends Clock{    
	private static final long serialVersionUID = 1L;
	static JLabel l = new JLabel("GPSʱ��");

	public GPS(){        
        add(l);
      
        l.setForeground(Color.white);
        l.setBounds(155, 100 , 200, 50);
        l.setFont(f);

        add(display2);
        display2.setForeground(Color.WHITE);
        display2.setBounds(125, 240, 250, 50);
        display2.setFont(f3);
        setVisible(true);
    }

	public void showUI(){ 	
		new Thread(new Runnable() {
			public void run() {
            	//System.out.println(Thread.currentThread().getName());
				setTimer(1);
				while(flag) {			
                	secs[0]++;
                	if(secs[0] == 60) {
                		secs[0] = 0;
                		mins[0]++;
                	}
                	if(mins[0] == 60) {
                		hours[0] += 1;
                		mins[0] = 0;
                	}
                	if(hours[0] == 24) {
                		hours[0] = 0;
                	}
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                    setTime(hours[0],mins[0],secs[0]);
                    //System.out.println("GPS:" + secs[0]);
                    showTime();
                    repaint();
                }
            }
		}).start();
    }
}
