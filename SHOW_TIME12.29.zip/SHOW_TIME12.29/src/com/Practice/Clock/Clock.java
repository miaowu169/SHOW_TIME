package com.Practice.Clock;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Date;
//import java.util.Timer;
//import java.util.TimerTask;
//import java.util.Timer;
//import java.util.TimerTask;
//import java.util.Timer;
//import java.util.TimerTask;

import javax.swing.JComponent;
import javax.swing.JLabel;

import com.Practice.time.TestNTP;

public abstract class Clock extends JComponent{
	  private static final long serialVersionUID = -5379472973578609775L;
	    protected Font f = new Font("΢���ź�",Font.PLAIN,50);//////l
	    protected Font f3 = new Font("΢���ź�",Font.BOLD,47);////display
	    protected Font f2 = new Font("΢���ź�",Font.BOLD,17);
	   // private JLabel l = new JLabel("����ʱ��");
	   // private JLabel l1 = new JLabel("����ʱ�� ��");
	    protected JLabel display = new JLabel();
	    protected JLabel display2 = new JLabel("");
	    protected int hour = 0;
	    protected int min = 0;
	    protected int sec = 0;
	    public boolean flag = true;
	    Date now;
	    int [] secs = new int[3];
	    int [] mins = new int[3];
	    int [] hours = new int[3];
	    
	    public void setFlag(boolean _flag) {
	    	flag = _flag;
	    }
	    int count=0;
	    public void setTimer(int millis) {
	    	
	    	TestNTP Time = new TestNTP();
	    	Date now = Time.getDate();
	    	
	    	setDate(now);
//	    	Timer timer = new Timer();
//	    	//ǰһ��ִ�г��������5min ��ʼִ����һ�γ���
//	    	 timer.schedule(new TimerTask() {    	     
//	    	      public void run() {
//  	    		  	TestNTP Time = new TestNTP();
//  	    		  	Date now = Time.getDate();
//  	    		  //System.out.println(count++);
//  	    		  	setDate(now);
//	    	       }
//	    	  },8*1000,1*1000);
	    	
	    	new Thread(new Runnable() {
	    	      public void run() {
	    	    	  while(true) {
	    	    		  	try {
								Thread.sleep(8*1000);
								//System.out.println(this.getClass().getName());
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
	    	    		  	TestNTP Time = new TestNTP();
	    	    		  	Date now = Time.getDate(); 
	    	    		  	setDate(now);
	    	    		  	//System.out.println(1);
	    	    	  	}
	    	      }
	    	      }).start();
	    	}
	    
	    
	    @SuppressWarnings("deprecation")
		public void setDate(Date now) {
	    	sec = now.getSeconds();
	    	min = now.getMinutes();
	    	hour = now.getHours();
	    	//System.out.println(sec);
	    	secs[0] = sec + 16;
	    	if (secs[0] >= 60){
	    		secs[0] -= 60;
	    	}
	    	//System.out.println(secs[0]);
	    	mins[0] = min;
	    	hours[0] = hour;
	    	//System.out.println(1);
	    	secs[1] = sec + 6;
	    	if (secs[1] >= 60){
	    		secs[1] -= 60;
	    	}
	    	mins[1] = min;
	    	hours[1] = hour;

	    	secs[2] = sec;
	    	mins[2] = min;
	    	hours[2] = hour - 8;
	    	if(hours[2]<0) {
	    		hours[2] = 24 + hours[2];
	    	}
	    	
	    }
	    
	    public void setTime(int _hour,int _min,int _sec) {
	    	this.hour = _hour;
	    	this.min = _min;
	    	this.sec = _sec;
	    }
	   
	    protected Graphics2D g;
	    final double PI = Math.PI;
	    protected String strTime = "" ;

		public Clock(){
		}
		
		@SuppressWarnings("deprecation")
		public void Init() {
  		  	TestNTP Time = new TestNTP();
  		  	Date now = Time.getDate();
	        hour = now.getHours();
	        min = now.getMinutes();
	        sec = now.getSeconds();
	    	secs[0] = sec + 16;
	    	if (secs[0] >= 60){
	    		secs[0] -= 60;
	    	}
	    	mins[0] = min;
	    	hours[0] = hour;
	    	secs[1] = sec + 6;
	    	if (secs[1] >= 60){
	    		secs[1] -= 60;
	    	}
	    	mins[1] = min;
	    	hours[1] = hour;
	    	secs[2] = sec;
	    	mins[2] = min;
	    	hours[2] = hour - 8;
	    }

	    public void paintComponent(Graphics g1){
	        double x,y;
	        super.paintComponent(g1);
	        g = (Graphics2D) g1;
	        //����ݿ��ؿ�
	        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	        
	        //������
	        g.setPaint(new GradientPaint(8,40,Color.WHITE,15,50,Color.WHITE,true));
	        g.setStroke( new BasicStroke(4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL));
	        g.drawOval(127, 440, 230, 230);//ʱ�ӱ���Բ
	        g.fillOval(235, 548, 14, 14);//ʱ������Բ����
	        g.setColor(Color.WHITE);

	        //��60����
	        for(int i = 0;i < 60;i++)
	        {
	            double[] co = new double[2];
	            co = paint_Dot(i * 2 * PI / 60);
	            x = co[0];
	            y = co[1];
	            if(i == 0 || i == 15 || i == 30 || i == 45)//��3,6,9,12�ĸ����
	            {
	                g.fillOval((int)(x+238),(int)(y+552),10,10);
	            }
	            else//����С��
	            {
	                g.fillOval((int)(x+242),(int)(y+555-1),3,3);
	            }
	        }
	        
	        //���ĸ�����
	        g.setFont(f2);
	        g.drawString("3", 322, 565);
	        g.drawString("6", 237, 650);
	        g.drawString("9", 152, 563);
	        g.drawString("12", 233, 475);
	        
	        //��ʱ�룬���룬����
	        paint_HourPointer(hour*3600 + min*60 + sec,g);//ʱ���߹�������
	        paint_MinutePointer(min*60 + sec,g);//�����߹�������
	        paint_SecondPointer(sec,g);//�����߹�������
	    }
	    
		public abstract void showUI();

	    public void paint_HourPointer(int second,Graphics2D g){//second��ʾ��ǰʱ���ʱ�����00:00:00���˶�����
	        double x,y,angle; 
	        angle = second * PI / 21600;//ʱ����ٶ�ΪPI/21600 (rad/s)
	        x = 242 + 45 * Math.sin(angle);
	        y = 555 - 45 * Math.cos(angle);
	        g.setStroke( new BasicStroke(4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
	        g.setPaint(new GradientPaint(200,255,Color.yellow,260,165,Color.white,true));
	        g.drawLine(242, 555, (int)x, (int)y);
	    }
	    
	    public void paint_MinutePointer(int second,Graphics2D g){//second��ʾ��ǰʱ��ķ������00:00:00���˶�����
	        double x,y,angle;
	        angle = second * PI / 1800;//������ٶ�ΪPI/1800 (rad/s)
	        x = 242 + 62 * Math.sin(angle);
	        y = 555 - 62 * Math.cos(angle);
	        g.setStroke( new BasicStroke(4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
	        g.setPaint(new GradientPaint(146,380,Color.white,280,165,Color.white,true));
	        g.drawLine(242, 555, (int)x, (int)y);
	    }
	    
	    @SuppressWarnings("unused")
		public void paint_SecondPointer(int second,Graphics2D g){//second��ʾ��ǰʱ����������00:00:00���˶�����
	        double x,y,x1,y1,angle;
	        double cos = 50 / Math.sqrt(2525);//
	        double sin = 5 / Math.sqrt(2525);
	        angle = second * PI / 30;//ʱ����ٶ�ΪPI/30 (rad/s)
	        x = 242 + 77 * Math.sin(angle);
	        y = 555 - 77 * Math.cos(angle);
	        x1 = 242 + 14 * Math.sin(angle + PI);
	        y1 = 555 - 14 * Math.cos(angle + PI);
	     
	        g.setStroke( new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
	        g.setPaint(new GradientPaint(146,380,Color.white,295,254,Color.white,true));
	        g.drawLine((int)x1, (int)y1, (int)x, (int)y);
	    }
	    
	    public double[] paint_Dot(double angle){
	        double[] co = new double[2];
	        co[0] = 105 * Math.cos(angle);//������
	        co[1] = 105 * Math.sin(angle);//������
	        return co;
	    }
	    

	    public void showTime(){
	        int hour_temp = hour,min_temp = min,sec_temp = sec;
	        sec_temp += 1 ;
//	        //System.out.println(sec_temp);
	        if(sec_temp >= 60)
	        {
	            sec_temp = 0;
	            min_temp += 1 ;
	        }
	        if(min_temp>=60){
	            min_temp=0;
	            hour_temp+=1;
	        }
	        if(hour_temp < 10)
	            strTime = "0" + hour_temp + ":";
	        else
	            strTime = "" + hour_temp + ":";
	         
	        if(min_temp < 10)
	            strTime = strTime + "0" + min_temp + ":";
	        else
	            strTime = strTime + "" + min_temp + ":";
	         
	        if(sec_temp < 10)
	            strTime = strTime + "0" + sec_temp;
	        else
	            strTime = strTime + "" + sec_temp;
	        //�ڴ�����������ʾʱ��
	        

	        strTime = "  " + strTime; 
	        display2.setText(strTime);
	    }
}
