package com.Practice.time;

import java.awt.FlowLayout;
import java.io.IOException;
import java.net.InetAddress;
import java.rmi.UnknownHostException;
import java.util.Date; 
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;

import javax.swing.JFrame;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.apache.commons.net.ntp.TimeStamp;

import com.Practice.Exception.TimeoutException;

public class TestNTP extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static Date date = null;
	public static String timeServerUrl;
	public static boolean flag = true;
	
	public void setTimeServerUrl(String URL) {
		timeServerUrl = URL;
	}
	
	 public void closePrograme() {
		 System.exit(0);
	 }
	
	 public Date getDate(){
		 JFrame f = new JFrame();
//		 JButton btn = new JButton("�˳�");

		 f.setLayout(new FlowLayout());
//		 f.add(btn);
//
//		 btn.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				System.exit(0);
//			}
//			 
//		 });
		 f.setTitle("linked error");
		 f.setSize(300,100);
		 f.setLocationRelativeTo(null);
		 
		  try {
		   NTPUDPClient timeClient = new NTPUDPClient();
		   InetAddress timeServerAddress = InetAddress.getByName(timeServerUrl);
		   
		   new Thread(new Runnable() {
			public void run() {
				try {
					//JOptionPane.showMessageDialog(null, "IP����ʧ��","���ӳ�ʱ!", JOptionPane.ERROR_MESSAGE);
					Thread.sleep(2000);	//2s�Ӻ�����Ӧ���׳��쳣	
					if(flag == true) {
						throw new TimeoutException();
					}
				} catch (InterruptedException e) {
					 //TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TimeoutException e) {
					  f.setVisible(true);
					  try {
						Thread.sleep(2000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					  System.exit(0);
				}
			}
			   
		   }).start();
		   
		   
		   TimeInfo timeInfo = timeClient.getTime(timeServerAddress);
		   TimeStamp timeStamp = timeInfo.getMessage().getTransmitTimeStamp();
		   
		   date = timeStamp.getDate();
		   flag = false;

		  } catch (UnknownHostException e) {
		   e.printStackTrace();
		  } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  return date;
	 }
	 

	 
	 public boolean getFlag() {
		 return flag;
	 }
}
