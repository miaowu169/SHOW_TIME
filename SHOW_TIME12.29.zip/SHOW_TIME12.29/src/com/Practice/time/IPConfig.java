package com.Practice.time;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.Practice.Exception.IPConfigException;
import com.Practice.Listener.Listener;
import com.Practice.Module.EmptyModule;
import com.Practice.file.FileOperation;


public class IPConfig{
	private JTextField [] field = new JTextField[4];
	private JLabel [] sj = new JLabel [3];
	private JButton btn= new JButton("ȷ��");
	private JButton btn1 = new JButton("Ĭ��IP");
	static String IPget = null;
	static JFrame IPConfigUI;
	JPanel jp = new JPanel();
	public void ConfigUI() {
		IPConfigUI = new JFrame("NTP��������ַ����");
        IPConfigUI.setResizable(false);  
        IPConfigUI.setSize(300,100);
        IPConfigUI.add(new JLabel("���ã�"));
        for(int i = 0;i < 4;i++) {
        	field[i] = new JTextField(4);
        }
        
        for(int j = 0;j < 3;j++) {
        	sj[j] = new JLabel(".");
        }
        
        IPConfigUI.add(jp);
        
        if(new File("IPConfig.txt").exists()) {
				try {
					String message = new FileOperation().read("IPConfig.txt");
					String [] text = message.split(",");
					//System.out.println(message);
		        	field[0].setText(text[0]);
		        	field[1].setText(text[1]);
		        	field[2].setText(text[2]);
		        	field[3].setText(text[3]);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        }else {
        	field[0].setText("40");
        	field[1].setText("81");
        	field[2].setText("94");
        	field[3].setText("65");
        }
        jp.add(field[0]);
        jp.add(sj[0]);
        jp.add(field[1]);
        jp.add(sj[1]);
        jp.add(field[2]);
        jp.add(sj[2]);
        jp.add(field[3]);
        
        jp.add(btn);
        jp.add(btn1);
       
        IPConfigUI.setLocationRelativeTo(null);
        IPConfigUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        IPConfigUI.setVisible(true);
		
    	btn.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
    			if(field[0].getText().equals("") || field[1].getText().equals("") || field[2].getText().equals("")  || field[3].getText().equals("")) {
    					JOptionPane.showMessageDialog(new JFrame(),"IP��ַ����Ϊ��","���ô���",JOptionPane.ERROR_MESSAGE);
    					return;
    			}
//    			if(field[0].getText().equals("")) {
//    				System.out.println("null");
//    			}
    			String IPStore = field[0].getText().trim() + " ," + field[1].getText().trim()
    					+ " ," + field[2].getText().trim() + " ," + field[3].getText().trim() + " ";
    			IPget = field[0].getText().trim() + "." + field[1].getText().trim() + "." + field[2].getText().trim() + "." +field[3].getText().trim();
    			System.out.println("IPget:"+IPget);
    			try {
					new FileOperation().write("IPConfig.txt",IPStore);
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
    			
    			try {
    	    		new EmptyModule().closeEmptyWindow();
    	    		IPConfigUI.dispose();
					new Listener().Update(IPget);
				} catch (IPConfigException e1) {
					
				}
    		}
    	});
    	
    	btn1.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
            	field[0].setText("40");
            	field[1].setText("81");
            	field[2].setText("94");
            	field[3].setText("65");
    		}
    	});
	}
	
	public String getIP() {
		return IPget;
	}
}
