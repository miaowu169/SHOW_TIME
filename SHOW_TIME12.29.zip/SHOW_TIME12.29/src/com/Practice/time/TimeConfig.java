package com.Practice.time;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.Practice.Module.workModule;
import com.Practice.file.FileOperation;

public class TimeConfig{
	private JLabel timeJLabel;
	private static JTextField hourField;
	private JButton btn= new JButton("ȷ��");
	static JFrame TimeConfigUI;
	private JPanel timePanel;
	public static int hour;
	
	JPanel jp = new JPanel();
	public void ConfigUI() {
		TimeConfigUI = new JFrame("ʱ���ȡ����");
		timePanel = new JPanel();
		TimeConfigUI.add(timePanel);
        TimeConfigUI.setResizable(false);  
        TimeConfigUI.setSize(360,100);
        timePanel.add(new JLabel("�Զ���ȡntpʱ�����ã�"));
        
        timeJLabel = new JLabel("hour/hours");
        hourField = new JTextField(7);
        
        timePanel.add(hourField);
        timePanel.add(timeJLabel);

        timePanel.add(btn);
        
        btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String time = hourField.getText();
				hour = Integer.parseInt(time)*60*60*1000;
				JOptionPane.showMessageDialog(new JFrame(),
						"ntp��ȡʱ�����óɹ���","���óɹ�",
						JOptionPane.INFORMATION_MESSAGE);
				new Thread(new Runnable() {
					public void run() {
						try {
							Thread.sleep(hour);
							new workModule().closeEmptyWindow();
							new workModule().showworkModule();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}			
				}).start();
			}    	
        }); 
        
        try {
			new FileOperation().write("getTime.txt", String.valueOf(hour));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        TimeConfigUI.setLocationRelativeTo(null);
        TimeConfigUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        TimeConfigUI.setVisible(true);
	}
	
	public String getTime() {
		return String.valueOf(hour);
	}
}
