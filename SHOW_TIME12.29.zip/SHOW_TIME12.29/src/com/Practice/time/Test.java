package com.Practice.time;

import com.Practice.Module.EmptyModule;

public class Test { 
    public static void main(String args[]){
    	EmptyModule oldmod = new EmptyModule();
    	oldmod.showEmptyModule();
    }
}
