package com.Practice.MenuEvent;

import com.Practice.file.FileOperation;
import com.Practice.time.IPConfig;

public class MessageInfor {
	protected String IPget;
	protected String titleName;
	protected String titleFontType;
	protected String titleFontSize;
	protected String titleFontColor;
	protected String titleFontMode;
	protected String FontType;
	protected String FontSize;
	protected String FontColor;
	protected String FontMode;
	protected String BackgroundColor;
	
	protected String time = null;
	protected String message = null;
	
	public MessageInfor() {
		try {
			time = new FileOperation().read("getTime.txt");
			message = new FileOperation().read("Message.txt");
			//int hour = Integer.parseInt(time)/60/60;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String mess[]=message.split(",");
		titleName = mess[0];
		titleFontType = mess[1];
		titleFontSize = mess[2];
		titleFontColor = mess[3];
		if(mess[4].equals("0")) {
			titleFontMode = "NORMAL";
		}else if(mess[4].equals("1")) {
			titleFontMode = "ITALIC";
		}else if(mess[4].equals("2")) {
			titleFontMode = "BOLD";
		}
		
		FontType = mess[5];
		FontSize = mess[6];
		FontColor = mess[7];
		FontMode = mess[8];
		
		if(mess[8].equals("0")) {
			FontMode = "NORMAL";
		}else if(mess[8].equals("1")) {
			FontMode = "ITALIC";
		}else if(mess[8].equals("2")) {
			FontMode = "BOLD";
		}
		
		try {
			BackgroundColor = new FileOperation().read("ColorConfig.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		IPget = new IPConfig().getIP();
	}	
}
